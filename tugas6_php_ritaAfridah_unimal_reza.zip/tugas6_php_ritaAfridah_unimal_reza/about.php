<section id="about" class="about">
    <div class="container">

        <div class="section-title">
            <h2>About Me</h2>
            <p>Halo.Perkenalkan saya Rita Afridah.saya merupakan mahasiswi semester 5 pada Universitas Malikussaleh
                yang berada di Lhokseumawe.saya berasal dari Kabupaten Labuhan Batu Selatan,Sumatera Utara
            </p>
        </div>

        <div class="row">
            <div class="col-lg-4" data-aos="fade-right">
                <img src="assets/img/profile-img.jpg" class="img-fluid" alt="">
            </div>
            <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
                <h3>Mahasiswi Teknik informatika.</h3>
                <p class="fst-italic">
                    Berikut ini saya lampirkan  data diri saya :
                </p>
                <div class="row">
                    <div class="col-lg-6">
                        <ul>
                            <li><i class="bi bi-chevron-right"></i> <strong>Birthday:</strong> <span>26 agustus 2002</span>
                            </li>
                            <li><i class="bi bi-chevron-right"></i> <strong>Email :</strong>
                                <span>ritaafrida4@gmail.com</span>
                            </li>
                            <li><i class="bi bi-chevron-right"></i> <strong>Phone:</strong> <span>082273927932</span>
                            </li>
                            <li><i class="bi bi-chevron-right"></i> <strong>Asal Kota:</strong> <span>Medan,Sumatera Utara</span>
                            </li>
                        </ul>
                    </div>
                    <div class="col-lg-6">
                        <ul>
                            <li><i class="bi bi-chevron-right"></i> <strong>Age:</strong> <span>20 years</span></li>
                            <li><i class="bi bi-chevron-right"></i> <strong>Hobby:</strong> <span>Reading novel</span></li>
                            <li><i class="bi bi-chevron-right"></i> <strong>Alamat kos:</strong><span>lrg.setia,Batuphat Barat</span>                           
                            <li><i class="bi bi-chevron-right"></i> <strong>fav Makanan:</strong><span>Mie ayam Bakso</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <p>
                    baik.itulah sedikit tentang pribadi saya,semoga bisa berkenalan teman-teman.terimakasih 
                    sudah mampir di website ini.
                </p>
            </div>
        </div>

    </div>
</section>