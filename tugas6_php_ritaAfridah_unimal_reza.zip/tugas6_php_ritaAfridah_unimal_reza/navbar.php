<nav id="navbar" class="nav-menu navbar">
    <ul>
        <li><a href="index.php?hal=home" class="nav-link scrollto active"><i class="bx bx-home"></i>
                <span>Home</span></a></li>
        <li><a href="index.php?hal=about" class="nav-link scrollto"><i class="bx bx-user"></i> <span>About</span></a>
        </li>
        <li><a href="index.php?hal=study" class="nav-link scrollto"><i class="bx bx-file-blank"></i>
                <span>My Study</span></a></li>
        <li><a href="index.php?hal=portfolio" class="nav-link scrollto"><i class="bx bx-book-content"></i>
                <span>Portfolio</span></a></li>
        <li><a href="index.php?hal=tasks" class="nav-link scrollto"><i class="bx bx-server"></i>
                <span>Tasks</span></a></li>
        <!--li><a href="#contact" class="nav-link scrollto"><i class="bx bx-envelope"></i>
                <span>Contact</span></a></li-->
    </ul>
</nav><!-- .nav-menu -->