 <!-- ======= Footer ======= -->
 <footer id="footer">
    <div class="container">
      <div class="copyright">
        rita @2022 <strong><span>kampus merdeka</span></strong>
      </div>
      <div class="credits">
       </div>
    </div>
  </footer>
   <!-- End  Footer -->
