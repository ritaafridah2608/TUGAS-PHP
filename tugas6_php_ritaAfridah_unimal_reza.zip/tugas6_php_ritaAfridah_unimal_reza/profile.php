<div class="profile">
        <img src="assets/img/profile-img.jpg" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light"><a href="index.html">Rita afridah</a></h1>
        <div class="social-links mt-3 text-center">   
          <a href="https://web.facebook.com/profile.php?id=100008664035623" target="_blank" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="https://www.instagram.com/afrda_ra/" target="_blank" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="https://www.tiktok.com/@raaaaa2608?lang=en" target="_blank" class="tiktok"><i class="bx bxl-tiktok"></i></a>
          <a href="https://github.com/ritaafridah2608" target="_blank" class="github"><i class="bx bxl-github"></i></a>
        </div>
</div>