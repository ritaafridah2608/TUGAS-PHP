 <section id="resume" class="resume">
     <div class="container">

         <div class="section-title">
             <h2>Riwayat pendidikan
                <br/> Pengalaman
                <br/> $ Kemampuan
             </h2>
         </div>

         <div class="row">
             <div class="col-lg-6" data-aosSuma="fade-up">
                 <h3 class="resume-title">Education</h3>
                    <div class="resume-item pb-0">
                        <h4>SDN 118394  Bis 2</h4>
                        <h5>2008 - 2014</h5>
                    </div>
                    <div class="resume-item pb-0">
                        <h4>MTs Al-Hidayah Cikampak</h4>
                        <h5>2014 - 2017</h5>
                    </div>
                    <div class="resume-item pb-0">
                        <h4>SMAN 1 TORGAMBA</h4>
                        <h5>2017 - 2020</h5>
                    </div>
                    <div class="resume-item pb-0">
                        <h4>UNIVERSITAS MALIKUSSALEH</h4>
                        <h5>2020- NOW</h5>
                    </div>

                 <h3 class="resume-title">Kemampuan</h3>
                 <div class="resume-item">
                     <h5><ul>
                         <li>Mampu menggunakan bahasa pemograman PHP,Java Script</li>
                         <li>Mampu menggunakan html </li>
                         <li>Mampu menggunakan VBA Excell</li>
                         <li>menguasai microsoft office </li>
                     </ul></h5>
                 </div>
             </div>
             <div class="col-lg-6" data-aos="fade-up" data-aos-delay="100">
                 <h3 class="resume-title">Pengalaman</h3>
                 <div class="resume-item">
                     <h5><ul>
                         <li>sebagai Bellira,pada ekstrakurikuller Drumband pada Saat SMA</li>
                         <li>Mengikuti ke Panitiaan Musyawarah wilayah PERMIKOMNAS WIL 1 </li>
                         <li>Mengikuti kepanitiaan pada acara Informatic study camp</li>
                         <li>membuat aplikasi sederhana tentang perbankan </li>
                     </ul></h5>
                 </div>
                 <h3 class="resume-title">my personality</h3>
                    <div class="resume-item pb-0">
                        <h5>
                            <ul>
                                <li>Jujur</li>
                                <li>Pekerja Keras</li>
                                <li>Disiplin</li>
                                <li>Mampu bekerja sama dengan tim</li>
                                <li>Bertanggung Jawab</li>
                            </ul>
                        </h5>
                    </div>   
                 </div>
             </div>
         </div>

     </div>
 </section>