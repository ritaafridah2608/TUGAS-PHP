<?php
abstract class Bentuk2D{
    abstract protected function luasBidang();
    abstract protected function kelilingBidang();
    
}